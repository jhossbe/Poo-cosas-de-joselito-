public abstract class FormaGeometrica {
    private double base;
    private double altura;


}
