public class Empleado {
    public final String idEmpleado;
    public String nombre;
    private double salario;


    public Empleado(String idEmpleado, String nombre, double salario) {
        this.idEmpleado = idEmpleado;
        this.nombre = nombre;
        this.salario = salario;
    }

    public String getIdEmpleado() {
        return idEmpleado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getSalario() {
        return salario;
    }

    public final void registrarIngreso(){
        System.out.println("Empleado registrado mediante huella digital");
    }

    public void mostrarInformacion(){

    }
    public void calcularBonificacion(){
        System.out.println("Bonificacion general del 5% del salario");
    }


}
